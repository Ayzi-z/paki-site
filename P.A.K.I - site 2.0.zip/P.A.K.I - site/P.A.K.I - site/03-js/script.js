/*Sistema do menu lateral*/
function chamar_menu(){
    const botao_menu = document.getElementById('botao_menu')
    const menu_lateral = document.getElementById('menu_lateral')

    if (menu_lateral.classList.contains('desativado')){
        menu_lateral.classList.remove('desativado')
    } else {
       menu_lateral.classList.add('desativado')
    };

    botao_menu.classList.toggle('botaomenu_clicado')
};

document.getElementById("botao_menu").addEventListener("click", chamar_menu)

/*SISTEMA DE TEMA*/

/* Função para mudar tema*/
document.getElementById("botao_tema").addEventListener("click",function(){
    let tema_salvo = localStorage.getItem('tema_salvo') || 'claro'; 
    const botao_tema = document.querySelector('#botao_tema')
        
    if (tema_salvo === 'escuro'){
            localStorage.setItem('tema_salvo','claro')
            botao_tema.textContent = '🌙'
        }
        else{
            localStorage.setItem('tema_salvo','escuro')
              botao_tema.textContent = '☀️'
        };
        tema_pagina()
});

/* Função para aplicar o tema*/